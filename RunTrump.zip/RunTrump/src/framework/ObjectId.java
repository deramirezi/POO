package framework;

public enum ObjectId {

	Player(),
	Block(),
	Bill(),
	WhiteJaus;

}
